<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>ZINE | Robotics and Research Group - Where imagination leads to creation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Zine - The only active robtics and research group MNIT for the last 7 years,since its foundation. We have participated in various nationals and internationals events related to a multitude of fields and have gained expertise in various concerned technologies areas. We have also been equally active in inter disciplinary research, at par with state of the art work going in diversified domains. Consistent team work coupled with perseverance, proper guidance, stimulating challenges have gained us numerous significant achievements.">
        <meta name="keywords" content="Robotics and Research">
        <meta name="author" content="ZINE">
        <link rel="icon" href="images/zine.png">
        <meta property="og:title" content="ZINE" />
        <meta property="og:type" content="website" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" />
        <link href="css/flexslider.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/elegant-icons.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/pe-icon-7-stroke.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/lightbox.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/theme-lava.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/custom.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/custom-blog.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,300" rel="stylesheet" type="text/css">
        <link href='http://fonts.googleapis.com/css?family=Droid+Serif|Open+Sans:400,700' rel='stylesheet' type='text/css'>
                <link href="https://fonts.googleapis.com/css?family=Raleway:800&display=swap" rel="stylesheet">
       
        <link href="https://fonts.googleapis.com/css?family=Montserrat:500&display=swap" rel="stylesheet">
    </head>
        <body class="no-loader">
        <div class="loader">
    		<div class="strip-holder">
				<div class="strip-1"></div>
				<div class="strip-2"></div>
				<div class="strip-3"></div>
    		</div>
    	</div>

    	<a id="top"></a>

		<div class="nav-container">

				<nav class="overlay-nav">
					<div class="container">
						<div class="row">
							<div class="col-md-2">
								<a  target="_self" class="inner-link" href="index.php"><img alt="ZINE" class="logo logo-light" src="img/ZINE/zine1.png">
								<img alt="ZINE" class="logo logo-dark" src="img/ZINE/zine1.png"></a>
							</div>

							<div class="col-md-10 text-right">
								<ul class="menu">
                                    <li><a target="_self" href="index.php">Home</a></li>
									<li><a target="_self" href="team.php">Team</a></li>
									<li><a target="_self" href="project/Projects.php">Projects</a></li>
									<li><a target="_self" href="achievements.php">Achievements</a></li>
                                    <li><a target="_self" href="about.php">About</a></li>	
									<li class="social-link hidden-md hidden-sm hidden-xs"><a target="_blank" href="https://www.facebook.com/ROBOTICS.ZINE"><i class="icon social_facebook"></i></a></li>
      								<li class="social-link hidden-md hidden-sm hidden-xs"><a target="_blank" href="https://www.instagram.com/zine.robotics"><i class="icon social_instagram"></i></a></li>
                                    <li class="social-link hidden-md hidden-sm hidden-xs"><a target="_blank" href="https://www.youtube.com/channel/UC92-Bhcl13KcI0UUU2ZrN1Q/featured"><i class="icon social_youtube"></i></a></li>
								    
								    <div class="mobile-menu-toggle"><i class="icon icon_menu"></i></div>
								</ul>
							</div>
						</div>
					</div>
					
					<div class="bottom-border"></div>
				</nav>
        </div>
    


    <body class="no-loader">
		<div class="main-container">
			<section class="hero-slider lazy-section">
				<ul class="slides">
					<li class="hero-slide">
						<div class="background-image-holder parallax-background">
							<img class="background-image" alt="Background Image" data-src="img/ZINE/slider5.jpg">
						</div>
						<div class="container">
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<h1 class="large-h1 text-white">Where Imagination Leads to Creation</h1>
								</div>
							</div>
						</div>
					</li>

					<li class="hero-slide">
						<div class="background-image-holder parallax-background">
							<img class="background-image" alt="Background Image" data-src="img/ZINE/slider3.jpeg">
						</div>

						<div class="container">   
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<h1 class="large-h1 text-white">Conducts Robotics Workshop Annually</h1>
									<a href="ComingSoon/commingsoon.html" target="_blank"><button class="btan btan-four">Coming Soon</button></a>
								</div>

							</div>
						</div>
					</li>

					<li class="hero-slide">
						<div class="background-image-holder parallax-background">
							<img class="background-image" alt="Background Image" data-src="img/ZINE/events.png">
						</div>
						<div class="container">
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<h1 class="large-h1 text-white">Participates in various national and international robotics events </h1>
                                    <a href="achievements.php" target="_blank"><button class="btan btan-four">Achievements</button></a>
								</div>
							</div>
						</div>
					</li>
                    <li class="hero-slide">
						<div class="background-image-holder parallax-background">
							<img class="background-image" alt="Background Image" data-src="img/ZINE/slider4.jpg">
						</div>
						<div class="container">
							<div class="row">
								<div class="col-sm-6 col-md-7">
									<h1 class="large-h1 text-white">Works on diverse research problems and innovative projects</h1>
                                    <a href="project/Projects.php" target="_blank"><button class="btan btan-four">Projects</button></a>
								</div>
							</div>
						</div>


                </ul>
			</section>
            
            		<section class="section">
                        <div class="background-image-holder parallax-background">
				<img class="background-image" alt="Background Image" data-src="img/ZINE/hero7.jpg">
			</div>
                        <div class="container">
						<div class="row">
							<div class="col-sm-12 text-center">
								<h1 class="large-h1-sub">About ZINE</h1>
                            </div>
                                <div class="col-sm-12">
                                    <div class="info-box">
                                    </div>
                                    <p>Zine is a creative group of engineering undergraduates of Malaviya National Institute of Technology, Jaipur who are together to learn, improve and apply their technical skills to help foster the growth of society and India in the field of technology by utilising their engineering skills to work on real time problems. It is comprised of students from various disciplines working under guidance of Dr. Rajesh Kumar from Electrical Engineering department and various alumni working in reputed firms and doing research in Universities in India and abroad. Zine has been the only active robotics and research group of MNIT for the last 11 years, since its foundation. 
                                </p>
                                </div>
                            </div>
						</div>
				</section>
            <a id="activities" class="in-page-link"></a>
			<section class="duplicatable-content visitor-info lazy-section">
					<div class="container">
						<div class="row">
							<div class="col-sm-12 text-center">
								<h1 class="large-h1-sub">ZINE Activities</h1>
								<br>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4 col-sm-6">
								<div class="info-box">
									<img alt="Venue" data-src="img/ZINE/compet.jpg">
									<h3 id="small_title">Robotics Competitions</h3>
									<p>Our team has participated and emerged victorious in various national and international robotics events for the past decade owing to the skills and commitment of our members. We firmly believe that having participated in various national and international level events has lended us valuable experience and a knack for victory competing alongside the most premiere robotics teams of India.</p>
                                    <div><br></div><div><br></div>
                                    <div class="text-link">
									<a href="achievements.php" target="_blank">Find Out About Achievements</a>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6">
								<div class="info-box">
									<img alt="Venue" data-src="img/ZINE/gallery/research.jpg">
									<h3 id="small_title">Research and Development<br></h3>
									<p> Our research falls in many domains including Artifical Intelligence, Controls and System, Gait Analysis, Human Robot Interaction, Algorithm Development and many more. Spanning all domains, ZINE Robotics has 9 patents and multiple papers in reputed IEEE Journals. ZINE has also collaborated with several hospitals for research and development.</p><br><div><br></div><div><br></div>
									<div class="text-link">
									<a href="./project/Projects.php" target="_blank">Find Out About our projects</a>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6">
								<div class="info-box">
									<img alt="Venue" data-src="img/ZINE/workshop.jpg">
									<h3 id="small_title">Workshop<br></h3>
                                    <div><p>Our team conducts a 9 day workshop that guides the incoming freshers into the field of robotics, along with lectures on various other engineering skills such as Android app development, Website Development, Ethical hacking and many basic lectures which are required to enhance your skills in Robotics. Every year our team had successfully delivered the impactful lectures and practicals to more than 300 freshers.</p><div><br></div><div><br></div>
									<div class="text-link">
										<a href="ComingSoon/commingsoon.html" target="_blank">Register for Workshop 2019</a>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
				</section>
            
			<section class="strip-divider primary-overlay lazy-section">
					<div class="background-image-holder parallax-background">
						<img class="background-image" alt="About Image" data-src="img/hero7.jpg">
					</div>
					<div class="video-wrapper">
						<video playsinline autoplay muted="" loop width='100%' height='100%'>
							<source src="video/Website_Compressed.mp4" type="video/mp4">
							<source src="video/video_2.ogv" type="video/ogg">
						</video>
					</div>
					<div class="container">
						<div class="row">
							<div class="col-sm-12 text-center">
                                <h1 class="text-white">Interested in joining team ZINE?<div>Registrations opening soon</div></h1>
							</div>
						</div>
					</div>
			</section>

<div class="footer-container">

						<section class="strip-divider call-to-action lazy-section " id="pad">
					<div class="background-image-holder parallax-background">
						<img class="background-image" alt="BG Image" data-src="img/grey-bg1.jpg">
					</div>
							<div class="text-center col-sm-12">
								<h1>Connect with ZINE!</h1>
								<ul class="social-icons icon-circle icon-zoom list-unstyled list-inline"> 
                            	      <li><a href="https://www.facebook.com/ROBOTICS.ZINE/?ref=bookmarks" target="_blank"><i class="fa fa-facebook"></i></a> </li> 
                                      <li><a href="https://play.google.com/store/apps/details?id=com.app.zine.zine" target="_blank"><i class="fa fa-android"></i></a> </li>   
	                                 <li> <a href="https://www.instagram.com/zine.robotics/" target="_blank"><i class="fa fa-instagram"></i></a> </li>
                                    <li> <a href="https://www.youtube.com/channel/UC92-Bhcl13KcI0UUU2ZrN1Q/featured" target="_blank"><i class="fa fa-youtube"></i></a> </li>
                                </ul>
                        </div>
			</section>
		</div>
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js" ></script>
		<script src="js/feednami.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/skrollr.min.js"></script>
        <script src="js/spectragram.min.js"></script>
        <script src="js/flexslider.min.js"></script>
        <script src="js/jquery.plugin.min.js"></script>
        <script src="js/jquery.countdown.min.js"></script>
        <script src="js/lightbox.min.js"></script>
        <script src="js/smooth-scroll.min.js"></script>
        <script src="js/placeholders.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/tweets.js"></script>
        <script src="js/blog.js"></script>
        	
    </body>
</html>